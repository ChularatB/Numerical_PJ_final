export default function Interpolation() {
    return (
        <>
            <center>
            <h3>Bisection Method</h3>

            <hr />
            </center>
        </>
)}