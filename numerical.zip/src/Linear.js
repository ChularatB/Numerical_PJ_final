

export default function Linear() {
    return (
        <>
            <center>
            <h3>Bisection Method</h3>

            <hr />
            </center>
        </>
)}